# config.py
API_ID = '00000'
API_HASH = 'aaaa111'
BOT_TOKEN = '00000aaaaaa'
SESSION_NAME = "MC_Njava"
SUDO_USERS = [0000, 000]

# Database Configuration
DB_HOST = "localhost"
DB_USER = "root"
DB_PORT = 3306
DB_PASSWORD = "Password"
DB_NAME = "najvabot"

